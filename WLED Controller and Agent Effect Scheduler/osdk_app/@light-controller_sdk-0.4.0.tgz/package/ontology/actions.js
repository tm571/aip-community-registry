"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dig2goSendJsonCommand = void 0;
var dig2goSendJsonCommand_js_1 = require("./actions/dig2goSendJsonCommand.js");
Object.defineProperty(exports, "dig2goSendJsonCommand", { enumerable: true, get: function () { return dig2goSendJsonCommand_js_1.dig2goSendJsonCommand; } });
