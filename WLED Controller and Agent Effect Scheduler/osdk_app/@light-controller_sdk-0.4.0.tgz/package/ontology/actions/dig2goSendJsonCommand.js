"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dig2goSendJsonCommand = void 0;
const OntologyMetadata_js_1 = require("../../OntologyMetadata.js");
exports.dig2goSendJsonCommand = {
    apiName: 'dig2goSendJsonCommand',
    type: 'action',
    osdkMetadata: OntologyMetadata_js_1.$osdkMetadata,
};
