import type { ActionDefinition, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/api';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace dig2goSendJsonCommand {
    type ParamsDefinition = {
        b1: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        b2: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        b3: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        bri: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        fx: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        g1: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        g2: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        g3: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        ix: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        on: {
            multiplicity: false;
            nullable: false;
            type: 'boolean';
        };
        r1: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        r2: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        r3: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        sx: {
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
    };
    interface Params {
        readonly b1: ActionParam.PrimitiveType<'integer'>;
        readonly b2: ActionParam.PrimitiveType<'integer'>;
        readonly b3: ActionParam.PrimitiveType<'integer'>;
        readonly bri: ActionParam.PrimitiveType<'integer'>;
        readonly fx: ActionParam.PrimitiveType<'integer'>;
        readonly g1: ActionParam.PrimitiveType<'integer'>;
        readonly g2: ActionParam.PrimitiveType<'integer'>;
        readonly g3: ActionParam.PrimitiveType<'integer'>;
        readonly ix: ActionParam.PrimitiveType<'integer'>;
        readonly on: ActionParam.PrimitiveType<'boolean'>;
        readonly r1: ActionParam.PrimitiveType<'integer'>;
        readonly r2: ActionParam.PrimitiveType<'integer'>;
        readonly r3: ActionParam.PrimitiveType<'integer'>;
        readonly sx: ActionParam.PrimitiveType<'integer'>;
    }
    interface Signatures {
        applyAction<P extends dig2goSendJsonCommand.Params, OP extends ApplyActionOptions>(args: P, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<P extends ReadonlyArray<dig2goSendJsonCommand.Params>, OP extends ApplyBatchActionOptions>(args: P, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"integer">} b1
 * @param {ActionParam.PrimitiveType<"integer">} b2
 * @param {ActionParam.PrimitiveType<"integer">} b3
 * @param {ActionParam.PrimitiveType<"integer">} bri
 * @param {ActionParam.PrimitiveType<"integer">} fx
 * @param {ActionParam.PrimitiveType<"integer">} g1
 * @param {ActionParam.PrimitiveType<"integer">} g2
 * @param {ActionParam.PrimitiveType<"integer">} g3
 * @param {ActionParam.PrimitiveType<"integer">} ix
 * @param {ActionParam.PrimitiveType<"boolean">} on
 * @param {ActionParam.PrimitiveType<"integer">} r1
 * @param {ActionParam.PrimitiveType<"integer">} r2
 * @param {ActionParam.PrimitiveType<"integer">} r3
 * @param {ActionParam.PrimitiveType<"integer">} sx
 */
export interface dig2goSendJsonCommand extends ActionDefinition<dig2goSendJsonCommand.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'dig2goSendJsonCommand';
        displayName: 'DIG2GO - Send JSON Command';
        modifiedEntities: {};
        parameters: dig2goSendJsonCommand.ParamsDefinition;
        rid: 'ri.actions.main.action-type.8d84c293-ac5a-44a3-80bc-18b1b922f33f';
        status: 'EXPERIMENTAL';
        type: 'action';
        signatures: dig2goSendJsonCommand.Signatures;
    };
    apiName: 'dig2goSendJsonCommand';
    type: 'action';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const dig2goSendJsonCommand: dig2goSendJsonCommand;
