export { Dig2goEffects } from './objects/Dig2goEffects.js';
