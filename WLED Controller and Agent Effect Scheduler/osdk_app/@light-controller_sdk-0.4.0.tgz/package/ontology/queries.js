"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.holidayWledEffectGenerator = void 0;
var holidayWledEffectGenerator_js_1 = require("./queries/holidayWledEffectGenerator.js");
Object.defineProperty(exports, "holidayWledEffectGenerator", { enumerable: true, get: function () { return holidayWledEffectGenerator_js_1.holidayWledEffectGenerator; } });
