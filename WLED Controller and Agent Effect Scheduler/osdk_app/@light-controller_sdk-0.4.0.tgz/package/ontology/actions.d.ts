export { dig2goSendJsonCommand } from './actions/dig2goSendJsonCommand.js';
