"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dig2goEffects = void 0;
var Dig2goEffects_js_1 = require("./objects/Dig2goEffects.js");
Object.defineProperty(exports, "Dig2goEffects", { enumerable: true, get: function () { return Dig2goEffects_js_1.Dig2goEffects; } });
