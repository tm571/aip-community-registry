import type { PropertyDef as $PropertyDef } from '@osdk/api';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/api';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/api';
export declare namespace Dig2goEffects {
    type PropertyKeys = 'id' | 'effects';
    type Links = {};
    interface Props {
        readonly effects: $PropType['string'][] | undefined;
        readonly id: $PropType['string'];
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<Dig2goEffects, Dig2goEffects.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof Dig2goEffects.Props = keyof Dig2goEffects.Props> = $Osdk.Instance<Dig2goEffects, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof Dig2goEffects.Props = keyof Dig2goEffects.Props> = OsdkInstance<OPTIONS, K>;
}
export interface Dig2goEffects extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'Dig2goEffects';
    __DefinitionMetadata?: {
        objectSet: Dig2goEffects.ObjectSet;
        props: Dig2goEffects.Props;
        linksType: Dig2goEffects.Links;
        strictProps: Dig2goEffects.StrictProps;
        apiName: 'Dig2goEffects';
        description: '';
        displayName: 'dig2go Effects';
        icon: {
            type: 'blueprint';
            color: '#155560';
            name: 'array-string';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'dig2go Effects';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             *   display name: 'Effects'
             */
            effects: $PropertyDef<'string', 'nullable', 'array'>;
            /**
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.58160d15-3e49-4330-b39a-dc0049e03eed';
        status: 'EXPERIMENTAL';
        titleProperty: 'id';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const Dig2goEffects: Dig2goEffects;
