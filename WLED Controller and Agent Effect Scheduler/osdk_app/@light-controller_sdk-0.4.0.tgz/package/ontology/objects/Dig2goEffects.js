"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dig2goEffects = void 0;
const OntologyMetadata_js_1 = require("../../OntologyMetadata.js");
exports.Dig2goEffects = {
    type: 'object',
    apiName: 'Dig2goEffects',
    osdkMetadata: OntologyMetadata_js_1.$osdkMetadata,
};
