"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.holidayWledEffectGenerator = void 0;
const OntologyMetadata_js_1 = require("../../OntologyMetadata.js");
exports.holidayWledEffectGenerator = {
    apiName: 'holidayWledEffectGenerator',
    type: 'query',
    version: '3.2.0',
    osdkMetadata: OntologyMetadata_js_1.$osdkMetadata,
};
