import type { QueryDefinition, VersionBound } from '@osdk/api';
import type { QueryParam, QueryResult } from '@osdk/api';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace holidayWledEffectGenerator {
    interface Signature {
        (query: holidayWledEffectGenerator.Parameters): Promise<holidayWledEffectGenerator.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly todaysDate: QueryParam.PrimitiveType<'datetime'>;
    }
    interface ReturnType {
        holidayName: QueryResult.PrimitiveType<'string'>;
        json: QueryResult.PrimitiveType<'string'>;
    }
}
export interface holidayWledEffectGenerator extends QueryDefinition<holidayWledEffectGenerator.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'holidayWledEffectGenerator';
        displayName: 'Holiday WLED Effect Generator';
        rid: 'ri.function-registry.main.function.b36ae744-febe-4abb-8bfa-591a7fbb5ce5';
        type: 'query';
        version: '3.2.0';
        parameters: {
            /**
             * (no ontology metadata)
             */
            todaysDate: {
                description: '';
                nullable: false;
                type: 'date';
            };
        };
        output: {
            nullable: false;
            struct: {
                holidayName: {
                    type: 'string';
                    nullable: false;
                };
                json: {
                    type: 'string';
                    nullable: false;
                };
            };
            type: 'struct';
        };
        signature: holidayWledEffectGenerator.Signature;
    };
    apiName: 'holidayWledEffectGenerator';
    type: 'query';
    version: '3.2.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const holidayWledEffectGenerator: holidayWledEffectGenerator;
