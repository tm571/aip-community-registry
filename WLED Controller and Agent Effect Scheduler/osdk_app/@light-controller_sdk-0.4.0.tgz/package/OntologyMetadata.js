"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.$ontologyRid = exports.$osdkMetadata = void 0;
exports.$osdkMetadata = { extraUserAgent: 'typescript-sdk/0.4.0 typescript-sdk-generator/2.0.12' };
exports.$ontologyRid = 'ri.ontology.main.ontology.a49b734f-a656-464a-99b1-1071925c00cc';
