export type $ExpectedClientVersion = '2.0.12';
export declare const $osdkMetadata: {
    extraUserAgent: string;
};
export declare const $ontologyRid = "ri.ontology.main.ontology.a49b734f-a656-464a-99b1-1071925c00cc";
