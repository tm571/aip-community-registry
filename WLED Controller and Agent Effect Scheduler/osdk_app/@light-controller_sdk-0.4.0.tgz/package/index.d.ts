export { dig2goSendJsonCommand } from './ontology/actions.js';
export * as $Actions from './ontology/actions.js';
export {} from './ontology/interfaces.js';
export * as $Interfaces from './ontology/interfaces.js';
export { Dig2goEffects } from './ontology/objects.js';
export * as $Objects from './ontology/objects.js';
export { holidayWledEffectGenerator } from './ontology/queries.js';
export * as $Queries from './ontology/queries.js';
export { $ontologyRid } from './OntologyMetadata.js';
